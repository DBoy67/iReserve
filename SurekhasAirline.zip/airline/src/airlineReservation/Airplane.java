package airlineReservation;

import java.util.HashMap;

public class Airplane {
	private Integer planeId;
	private String airplaneName;
	private HashMap<Integer, Seat> bookedSeatsTotal;
	private HashMap<Integer, Seat> bookedSeatsFirst;
	private HashMap<Integer, Seat> bookedSeatsEconomy;
	private int maxSeats;

	public Airplane(Integer plainId, String airplaneName, int maxSeats){
		this.planeId = plainId;
		this.airplaneName = airplaneName;
		this.maxSeats = maxSeats;
		bookedSeatsTotal = new HashMap<Integer, Seat>();
		bookedSeatsFirst = new HashMap<Integer, Seat>();
		bookedSeatsEconomy = new HashMap<Integer, Seat>();
	}


	public int getMaxSeats() {
		return maxSeats;
	}

	public void setMaxSeats(int maxSeats) {
		this.maxSeats = maxSeats;
	}

	public String[] getEmptySeatsBusiness(){
		//Seat s = new Seat(2, TravelClass.Business);
		//seatMapBusiness.put(2, s);
		int occupied =	bookedSeatsFirst.size();
		int arrcounter = 0;
		
		String[] emptyBusinessSeats = new String[5-occupied];
		for(int i = 1; i<=5; i++){
			if(!bookedSeatsFirst.containsKey(i)){
				emptyBusinessSeats[arrcounter]=String.valueOf(i);
				arrcounter = arrcounter + 1;
			}
		}
		return emptyBusinessSeats;
	}
	
	public String[] getEmptySeatsEconomy(){
		//Seat s = new Seat(2, TravelClass.Economy);
		//seatMapEconomy.put(2, s);
		int occupied =	bookedSeatsEconomy.size();
		int arrcounter = 0;
		
		String[] emptyEconomySeats = new String[5-occupied];
		for(int i = 6; i<=10; i++){
			if(!bookedSeatsEconomy.containsKey(i)){
				emptyEconomySeats[arrcounter]=String.valueOf(i);
				arrcounter = arrcounter + 1;
			}
		}
		return emptyEconomySeats;
	}

	public HashMap<Integer, Seat> getBookedSeats(){
		return bookedSeatsTotal;
	}

	public boolean isSeatFree(Integer seatNo, TravelClass travelClass){
		if(bookedSeatsTotal.containsKey(seatNo)){
			return false;
		}
		if( (seatNo<=5 && travelClass == TravelClass.First) || ((seatNo >5 && seatNo <=10) &&travelClass == TravelClass.Economy)){
			return true;
		}
		return false;
	}

	public Seat getSeat(Integer seatNo) throws ExSeatNotFound{
		return bookedSeatsTotal.get(seatNo);
	}

	public String getName(){
		return airplaneName;
	}

	public Integer getPlaneId(){
		return planeId;
	}

	public void selectSeat(Integer seatNo, Seat seat, TravelClass travelClass){
		bookedSeatsTotal.put(seatNo,  seat);
//		if(String.valueOf(travelClass).equals("Business")){
		if(TravelClass.First==travelClass){
		bookedSeatsFirst.put(seatNo, seat);
		}
		else{
			bookedSeatsEconomy.put(seatNo, seat);
		}
	}
	
	



}
