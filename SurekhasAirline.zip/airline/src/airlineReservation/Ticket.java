package airlineReservation;

public class Ticket {

	private String bookingCode;
	private String TicketNo;
	private Customer customer;
	private Seat seat;
	Airplane airPlane;
	private double price;
	
	public Ticket(String bookingCode, String ticketNo, Customer customer, Airplane airPlane,  Seat seat, double price) {
		super();
		this.bookingCode = bookingCode;
		TicketNo = ticketNo;
		this.customer = customer;
		this.seat = seat;
		this.price = price;
		this.airPlane = airPlane;
		seat.setSeatStatusReserved();
	}

	public Airplane getAirPlane() {
		return airPlane;
	}

	public void setAirPlane(Airplane airPlane) {
		this.airPlane = airPlane;
	}

	public String getBookingCode() {
		return bookingCode;
	}

	public void setBookingCode(String bookingCode) {
		this.bookingCode = bookingCode;
	}

	public String getTicketNo() {
		return TicketNo;
	}

	public void setTicketNo(String ticketNo) {
		TicketNo = ticketNo;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Seat getSeat() {
		return seat;
	}

	public void setSeat(Seat seat) {
		this.seat = seat;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	public String toString(){
		return "  "+bookingCode +"  " + TicketNo +"  " +airPlane.getPlaneId()+"  " +customer.getName() +"  " +seat.getSeatNo()+"  "+price   ;
		
		
	}
	
	
}
