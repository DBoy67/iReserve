package airlineReservation;

import java.util.HashMap;

public class FlightInformation {

	private Airplane airPlane;
	StringUtility strUtil = new StringUtility();

	public FlightInformation(){

	}

	public void printFlightSeatSatus(Airplane airPlane, HashMap<Integer, Ticket> bookings){
		System.out.println(" -------------------------------------------------------------------------------");
		//10 - 25 - 5 - 15 - 20
		System.out.println("�               Flight No: " + airPlane.getPlaneId() + "      Plane Type: " + airPlane.getName()+ "                      �");
		System.out.println(" --------------------------------------------------------------------------------");
		System.out.println("� Seat No   Flyer Name               Age  Class          Food Option            �");
		System.out.println(" --------------------------------------------------------------------------------");
		for(Integer i = 1; i <= airPlane.getMaxSeats(); i++){


			if(airPlane.getBookedSeats().containsKey(i) && bookings.containsKey(i)){
				//bookings.get(i).getAirPlane().getPlaneId() == airPlane.getPlaneId()
				Ticket t = bookings.get(i);
				if(airPlane.getPlaneId()== t.getAirPlane().getPlaneId()){
					String seatNo = strUtil.getPaddedString(airPlane.getBookedSeats().get(i).getSeatNo().toString(), 12, " ");					
					String flyer = strUtil.getPaddedString(t.getCustomer().getName(), 25, " ");
					String age = strUtil.getPaddedString(String.valueOf(t.getCustomer().getAge()), 5, " ");
					String travelClass = strUtil.getPaddedString(t.getSeat().getTravelClass().toString(),15," ");
					System.out.println(seatNo + flyer + age + travelClass);
				}
			}
			else
			{
				System.out.println( strUtil.getPaddedString(String.valueOf(i),10," " ));
			}
		}


	}
}
