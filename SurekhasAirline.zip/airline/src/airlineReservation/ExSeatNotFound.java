package airlineReservation;

public class ExSeatNotFound extends Exception {
String error;
	public ExSeatNotFound(String error){
		this.error = error;
	}
	
	public String getError(){
		return this.error;
	}
}
