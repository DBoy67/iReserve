package airlineReservation;

public enum TravelClass {
Economy,Business,First;
}
