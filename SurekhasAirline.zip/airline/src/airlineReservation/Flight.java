package airlineReservation;

public class Flight {

}
