package airlineReservation;

public class StringUtility {

	public String getPaddedString(String input, int expLength, String paddingChar){
		
		if(input.length() >= expLength){
			input = input.substring(0, expLength-1);
		}
		else
		{
			for(int i = 0; i < expLength; i++){
				input = input + paddingChar;
			}
			input = input.substring(0, expLength);
		}
		return input;
	}
}
