package airlineReservation;

import java.util.HashMap;

public class Booking {

	private Customer customer;
	private Seat seat;
	//	private Food food;
	private int maxSeat =10;
	HashMap<Integer, Airplane> fleet;
	HashMap<Integer, Ticket> ticketCatalog;
	private Ticket ticket;


	public Booking(){
		fleet = new HashMap<Integer, Airplane>();
		Airplane Boeing777 = new Airplane(111, "Boeing 777" ,10);
//		Airplane Boeing767 = new Airplane(222, "Boeing 767" ,10);
//		Airplane Boeing717 = new Airplane(333, "Boeing 717" ,10);
		fleet.put(111, Boeing777);
//		fleet.put(222, Boeing767);
//		fleet.put(333, Boeing717);
		ticketCatalog = new HashMap<Integer, Ticket>();

	}

	public Ticket bookTicket(Integer planeNo, TravelClass travelClass,Integer seatNo,String name,int age){

		Airplane airplane = fleet.get(planeNo);
		
		if (airplane.isSeatFree(seatNo, travelClass)) {
			customer = new Customer(name,age);
			seat = new Seat(seatNo, travelClass);
			airplane.selectSeat(seatNo, seat, travelClass);
			ticket = new Ticket("AV345",  "7711256" , customer, airplane, seat, 20000.00);
			
			ticketCatalog.put(seat.getSeatNo(), ticket);
			return ticket;
		} else {


		}

		return ticket;

	}

public HashMap<Integer, Airplane> getFlights(){
	return fleet;
}

public HashMap<Integer, Ticket> getTicketCatalog(){
	return ticketCatalog;
}



}
