package airlineReservation;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JTable;
import javax.swing.border.LineBorder;

import java.awt.Color;

import javax.swing.table.DefaultTableModel;
import javax.swing.BoxLayout;
import javax.swing.JDesktopPane;
import javax.swing.JLabel;

import java.awt.GridLayout;
import java.awt.Font;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Arrays;

public class test extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JButton btnNewButton;
	private JLabel lblFlightReservationWindow;
	private JComboBox TClass;
	private JComboBox SeatSelected;
	
	static Booking b = new Booking();
	static Airplane a = b.getFlights().get(1017);
	private JComboBox Flights;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					test frame = new test();
					frame.setVisible(true);
					test t = new test();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	@SuppressWarnings("unchecked")
	public test() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 644, 457);
		contentPane = new JPanel();
		setContentPane(contentPane);
		
		btnNewButton = new JButton("New button");
		btnNewButton.setBounds(529, 147, 89, 25);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("********* Clicked Button");
			}
		});
		
		table = new JTable();
		table.setBounds(294, 91, 324, 42);
		DefaultTableModel tm = new DefaultTableModel(4,4);
		contentPane.setLayout(null);
		
		lblFlightReservationWindow = new JLabel("Flight Booking System");
		lblFlightReservationWindow.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblFlightReservationWindow.setBounds(215, 0, 176, 25);
		contentPane.add(lblFlightReservationWindow);
		table.setModel(tm);
		table.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		contentPane.add(table);
		contentPane.add(btnNewButton);
		
		TClass = new JComboBox();
		TClass.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if(TClass.getSelectedItem().toString().equals("Business")){
					SeatSelected.setModel(new DefaultComboBoxModel(a.getEmptySeatsBusiness()));
					contentPane.add(SeatSelected);	
				}
				else{
					SeatSelected.setModel(new DefaultComboBoxModel(a.getEmptySeatsEconomy()));
					contentPane.add(SeatSelected);					
				}
			}
		});
		TClass.setModel(new DefaultComboBoxModel(TravelClass.values()));
		TClass.setBounds(20, 56, 131, 25);
		contentPane.add(TClass);
		
		SeatSelected = new JComboBox();
		SeatSelected.setModel(new DefaultComboBoxModel(a.getEmptySeatsBusiness()));
		SeatSelected.setBounds(20, 86, 131, 25);
		contentPane.add(SeatSelected);
		
		JButton btnBookFlight = new JButton("Book Flight");
		btnBookFlight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Integer planeNo = Integer.valueOf(Flights.getSelectedItem().toString());
				TravelClass t = TravelClass.valueOf(TClass.getSelectedItem().toString());
				Integer is = Integer.valueOf(SeatSelected.getSelectedItem().toString());
				b.bookTicket(planeNo, t, is, "KK", 39);
				SeatSelected.setModel(new DefaultComboBoxModel(a.getEmptySeatsBusiness()));
				contentPane.add(SeatSelected);	
			}
		});
		btnBookFlight.setBounds(20, 126, 131, 23);
		contentPane.add(btnBookFlight);
		
		Flights = new JComboBox();
		Flights.setModel(new DefaultComboBoxModel(new String[] {"1017", "0107", "0702"}));
		Flights.setBounds(18, 24, 133, 21);
		contentPane.add(Flights);
		
		
	}
}
