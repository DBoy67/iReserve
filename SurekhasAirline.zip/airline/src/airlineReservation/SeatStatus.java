package airlineReservation;

public enum SeatStatus {
Free,Reserved;
}
