package airlineReservation;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

//import org.bouncycastle.crypto.MaxBytesExceededException;

public class Reservation {
/*
	private HashMap<Integer, Airplane> fleet;
	private double flightFare; 
	public static int totalReservations;
	private int maxSeats = 10;
	private Customer customer;
	private Seat seat;
	private HashMap<Integer, Ticket> bookedTickets;
	private Ticket ticket;

	public Reservation(){
		fleet = new HashMap<Integer, Airplane>();
		Airplane Boing717 = new Airplane(1710, "Boing 717", maxSeats);
		Airplane Boing767 = new Airplane(0701, "Boing 767", maxSeats);
		fleet.put(Boing717.getPlaneId(), Boing717);
		fleet.put(Boing767.getPlaneId(), Boing767);
		totalReservations = 0;
		bookedTickets = new HashMap<Integer, Ticket>();
	}

	public Ticket bookTicket(Integer planeNo, Integer seatNo, TravelClass travelClass, double price, String firstName, String lastName, int age) throws ExSeatNotFound{
           Airplane airplane = fleet.get(planeNo);
		if(airplane.isSeatFree(seatNo, travelClass)){

			if( (seatNo<=5 && travelClass == TravelClass.Business) || ((seatNo >5 && seatNo <=10) &&travelClass == TravelClass.Economy)){
				seat = new Seat(seatNo, travelClass);
				airplane.selectSeat(seatNo, seat, null);
				customer = new Customer(firstName, lastName, age);
				ticket = new Ticket("1001", "12345678", customer, airplane, seat, price);
				bookedTickets.put(ticket.getSeat().getSeatNo(), ticket);
				return ticket;
				
			}
			else{
				throw new ExSeatNotFound("Requested Seat no: " + seatNo + " is not available for " + travelClass+ "class");
			}
		}
		else{
			throw new ExSeatNotFound("Requested seat (No " + seatNo+ ") is already Booked on Plane: " + airplane.getName());
		}

	}

	public Airplane getAirPlane(Integer planeId){
		return fleet.get(planeId);
	}

	public HashMap<Integer, Ticket> getBookedTickets(){
		return bookedTickets;
	}



	public static void main(String [] args){
		try{
			Reservation reservation = new Reservation();
			Ticket t;
			t = reservation.bookTicket(1710, 5, TravelClass.Business, 7850.00, "Annika","Patil", 2);
			t = reservation.bookTicket(1710, 2, TravelClass.Business, 7850.00, "Devansh","Patil", 4);
			t = reservation.bookTicket(1710, 3, TravelClass.Business, 7850.00, "Surekha","Patil", 35);
			t = reservation.bookTicket(1710, 4, TravelClass.Business, 7850.00, "Kedarnath","Patil", 39);
			t = reservation.bookTicket(1710, 1, TravelClass.Business, 7850.00, "Nalini","Pawar", 63);

			FlightInformation fi = new FlightInformation();
			fi.printFlightSeatSatus(reservation.getAirPlane(1710), reservation.getBookedTickets());
		}
		catch(ExSeatNotFound e){
			System.out.println(e.getError());
		}
	}*/
	
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to Star Airlines,Select the Travel Class : (F/E)");
		String option = sc.nextLine().toUpperCase(); 
		
Booking booking = new Booking();
		
		HashMap<Integer, Airplane> flights = booking.getFlights();
		Iterator<Airplane> iterator = flights.values().iterator();
		Airplane flight1 = iterator.next();	
		TravelClass tc;
		
		if(option.equals("F") ){
			System.out.println(Arrays.toString(flight1.getEmptySeatsBusiness()));
		tc = TravelClass.First;	
		}
		else {
		tc = TravelClass.Economy;
			System.out.println(Arrays.toString(flight1.getEmptySeatsEconomy()));
		}
				System.out.println("Please select seat from above");
		Integer seatNo = Integer.valueOf(sc.nextLine());
//		Seat seat = new Seat(seatNo, tc);
	System.out.println("Please Enter your Name and age separated by comma: ");
	String custInfo = sc.nextLine();
	String name = custInfo.split(",")[0];
	int age = Integer.parseInt(custInfo.split(",")[1]);
	System.out.println(name + " - " + age);
//	Customer cust = new Customer(name, age);
	Ticket t = booking.bookTicket(flight1.getPlaneId(), tc, seatNo, name, age);
	if(t!=null){
		System.out.println(t.toString());
	}
	else{
		System.out.println("Ticket not created");
	}
Reservation reservation = new Reservation();
	FlightInformation fi = new FlightInformation();
	fi.printFlightSeatSatus(flight1, booking.getTicketCatalog());
//		while(iterator.hasNext() ){
//			System.out.println(iterator.next().getPlaneId());
//		}
		
		
		
			
	}
}
