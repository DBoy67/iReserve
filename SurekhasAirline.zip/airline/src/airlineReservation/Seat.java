package airlineReservation;

public class Seat {
	private Integer seatNo;
	private SeatStatus status;
	private TravelClass travelClass;

	public Seat(Integer seatNo, TravelClass travelClass){
		this.seatNo = seatNo;
		this.status = SeatStatus.Free;
		this.travelClass = travelClass;
	}

	public void setSeatStatusReserved(){
		this.status = SeatStatus.Reserved;
	}
	
	public void setSeatStatusFree(){
		status = SeatStatus.Free;
	}
	
	public SeatStatus getSeatStatus(){
		return status;
	}
	
	public Integer getSeatNo(){
		return seatNo;
	}
	public TravelClass getTravelClass(){
		return travelClass;
	}

}
